HR sample files
valid_*  should attach to an employee relations case (pdf, png, jpg, docx, xlsx, txt, wav, mp3, m4a; max 15 MB).
too_big_16MB.pdf and empty_zero_bytes.pdf, wrong_type_* , fake_* must be refused. fake_* have an allowed extension but the wrong content:
the server checks the file itself, so these must be refused too.
bank_return_*  are for Payroll > pay run > Import bank returns (csv/txt/tsv, 1 MB at most).
bank_return_valid.csv has Amount 0.00 as a placeholder: edit the Amount to the NET PAY on the payslip of 'Test Thandi Nkosi'
(account 62000000011) or it will show as no match. A match needs the same account and the same amount to the cent.
